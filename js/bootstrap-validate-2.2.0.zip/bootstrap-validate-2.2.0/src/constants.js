module.exports = {
  CLASS_ERROR: "is-invalid",
  ELEMENT_HELP_BLOCK: "div",
  CLASS_HELP_BLOCK: "invalid-feedback",
  SEPARATOR_RULE: "|",
  SEPARATOR_OPTION: ":",
  LISTENER: "input"
};

export default module.exports;
